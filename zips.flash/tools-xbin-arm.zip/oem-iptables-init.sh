#!/system/bin/sh

##
## Install:
##  mount -o remount,rw /system
##  install -m750 -oroot -groot -p oem-iptables-init.sh /system/bin/oem-iptables-init.sh
##  mount -o remount,ro /system
##  reboot
##

IPTABLES=/system/bin/iptables
IP6TABLES=/system/bin/ip6tables
IPTABLES_OPTS='--wait'
IP6TABLES_OPTS='--wait'

# default policy
$IPTABLES $IPTABLES_OPTS -P INPUT DROP
$IPTABLES $IPTABLES_OPTS -P OUTPUT DROP
$IPTABLES $IPTABLES_OPTS -P FORWARD DROP
$IP6TABLES $IPTABLES_OPTS -P INPUT DROP
$IP6TABLES $IPTABLES_OPTS -P OUTPUT DROP
$IP6TABLES $IPTABLES_OPTS -P FORWARD DROP
$IP6TABLES $IPTABLES_OPTS -I INPUT -j REJECT
$IP6TABLES $IPTABLES_OPTS -I OUTPUT -j REJECT

# CLAMP MSS to PMTU
$IPTABLES $IPTABLES_OPTS -t mangle -A FORWARD -p tcp -m tcp --tcp-flags SYN,RST SYN -j TCPMSS --clamp-mss-to-pmtu

## OrWall Init stub
##
# check if orwall iptables already initialized, do nothing
if $IPTABLES $IPTABLES_OPTS -C ow_OUTPUT_LOCK -j DROP 2>/dev/null 
then
  exit 0
else
  #Create
  $IPTABLES $IPTABLES_OPTS -N ow_OUTPUT_LOCK
  $IPTABLES $IPTABLES_OPTS -N ow_INPUT_LOCK
  $IPTABLES $IPTABLES_OPTS -A ow_OUTPUT_LOCK -j DROP
  $IPTABLES $IPTABLES_OPTS -A ow_INPUT_LOCK  -j DROP
fi
## EOF
